from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
import pyttsx3
root = Tk()
root.geometry("1100x700")
root.minsize(1100,700)
root.maxsize(1100,700)
root['bg'] = 'skyblue'

def speak():
    content = txtbox.get(1.0,END)
    option = int(ecv.get())
    vs = int(ecvs.get())
    engine = pyttsx3.init('sapi5')
    voices = engine.getProperty('voices')
    engine.setProperty('voice',voices[option].id)
    engine.setProperty('rate',vs)
    engine.say(content)
    engine.runAndWait()



lbl_title = Label(root,text="AI Speaker",font='arial 27 bold',bg = 'lightgray')
lbl_title.pack(pady=50)

lbl_vo = Label(root,text="Choose Voice Option:",font='arial 17 bold',bg = 'lightgray')
lbl_vo.place(x=70,y=140)

ecv = ttk.Combobox(root,values=[0,1],font='arial 12 bold')
ecv.place(x=330,y=140)

lbl_vs = Label(root,text="Choose Voice Speed:",font='arial 17 bold',bg = 'lightgray')
lbl_vs.place(x=560,y=140)

ecvs = ttk.Combobox(root,values=[80,90,100,110,120,130,140,150,160,170,180,190,200,210,220,230,240,250,260,270,280,290,300],font='arial 12 bold')
ecvs.place(x=820,y=140)

frm = Frame(root,width=470,height=400)
frm.place(x=60,y=220)
img = Image.open('sbg.jpeg')
img = img.resize([470,400])
img = ImageTk.PhotoImage(img)
lbl_img = Label(frm,image=img)
lbl_img.pack()

txtbox = Text(root,width=57,height=21)
txtbox.place(x=560,y=220)

btn_sub = Button(root,text="Speak",font='arial 18 bold',command=speak)
btn_sub.place(x=640,y=590)

mainloop()





